//
//  BoltAI2Crack.h
//  BoltAI2Crack
//
//  Created by MacXK on 2026/1/11.
//

#import <Foundation/Foundation.h>

//! Project version number for BoltAI2Crack.
FOUNDATION_EXPORT double BoltAI2CrackVersionNumber;

//! Project version string for BoltAI2Crack.
FOUNDATION_EXPORT const unsigned char BoltAI2CrackVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BoltAI2Crack/PublicHeader.h>
