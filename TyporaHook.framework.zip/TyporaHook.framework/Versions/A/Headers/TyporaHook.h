//
//  TyporaHook.h
//  TyporaHook
//
//  Created by MacXK on 2026/1/8.
//

#import <Foundation/Foundation.h>

//! Project version number for TyporaHook.
FOUNDATION_EXPORT double TyporaHookVersionNumber;

//! Project version string for TyporaHook.
FOUNDATION_EXPORT const unsigned char TyporaHookVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TyporaHook/PublicHeader.h>
